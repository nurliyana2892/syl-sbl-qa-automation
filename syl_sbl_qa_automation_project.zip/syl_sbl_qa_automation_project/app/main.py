from flask import Flask, render_template, request, jsonify, redirect, url_for, session
from core.limit_engine import calculate_limits, evaluate_lot, calculate_shift_ratio, requires_limit_review

app = Flask(__name__)
app.secret_key = "demo-secret-key"

USERS = {"qapm": "quality123"}

sample_yields = [96.8, 97.1, 96.5, 97.3, 96.9, 97.0, 96.7, 97.2, 96.6, 97.4,
                 96.8, 97.1, 96.9, 97.0, 96.7, 97.2, 96.5, 97.1, 96.8, 97.0,
                 96.9, 97.3, 96.6, 97.2, 96.8, 97.1, 96.7, 97.0, 96.9, 97.2]
sample_bins = [0.6, 0.7, 0.5, 0.8, 0.6, 0.7, 0.6, 0.9, 0.5, 0.7,
               0.6, 0.8, 0.7, 0.6, 0.5, 0.8, 0.6, 0.7, 0.6, 0.8,
               0.7, 0.6, 0.5, 0.8, 0.7, 0.6, 0.7, 0.8, 0.6, 0.7]

current_limits = calculate_limits(sample_yields, sample_bins, "standard")

lot_decisions = []

@app.route("/")
def index():
    if not session.get("logged_in"):
        return redirect(url_for("login"))
    return redirect(url_for("dashboard"))

@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        if USERS.get(request.form.get("username")) == request.form.get("password"):
            session["logged_in"] = True
            return redirect(url_for("dashboard"))
        error = "Invalid username or password"
    return render_template("login.html", error=error)

@app.route("/dashboard")
def dashboard():
    if not session.get("logged_in"):
        return redirect(url_for("login"))
    return render_template("dashboard.html", limits=current_limits, decisions=lot_decisions)

@app.route("/limits", methods=["GET", "POST"])
def limits():
    if not session.get("logged_in"):
        return redirect(url_for("login"))

    result = current_limits
    if request.method == "POST":
        product_type = request.form.get("product_type")
        result = calculate_limits(sample_yields, sample_bins, product_type)

    return render_template("limits.html", result=result)

@app.route("/lot-evaluation", methods=["GET", "POST"])
def lot_evaluation():
    if not session.get("logged_in"):
        return redirect(url_for("login"))

    result = None
    if request.method == "POST":
        lot_id = request.form.get("lot_id")
        yield_percent = float(request.form.get("yield_percent"))
        bin_rate_percent = float(request.form.get("bin_rate_percent"))
        bin_qty = int(request.form.get("bin_qty"))
        small_quantity_rule = request.form.get("small_quantity_rule") == "on"
        asic_sbin = request.form.get("asic_sbin") == "on"

        result = evaluate_lot(
            yield_percent=yield_percent,
            bin_rate_percent=bin_rate_percent,
            bin_qty=bin_qty,
            syl=current_limits["syl"],
            sbl=current_limits["sbl"],
            sml=current_limits["sml"],
            small_quantity_rule=small_quantity_rule,
            asic_sbin=asic_sbin
        )
        record = {
            "lot_id": lot_id,
            "yield_percent": yield_percent,
            "bin_rate_percent": bin_rate_percent,
            "bin_qty": bin_qty,
            "decision": result["decision"],
            "reasons": ", ".join(result["reasons"]) if result["reasons"] else "NA"
        }
        lot_decisions.append(record)

    return render_template("lot_evaluation.html", limits=current_limits, result=result, decisions=lot_decisions)

@app.route("/limit-review", methods=["GET", "POST"])
def limit_review():
    if not session.get("logged_in"):
        return redirect(url_for("login"))

    result = None
    if request.method == "POST":
        calculated = float(request.form.get("calculated_limit"))
        original = float(request.form.get("original_limit"))
        long_term_sigma = float(request.form.get("long_term_sigma"))
        shift_ratio = calculate_shift_ratio(calculated, original, long_term_sigma)
        result = {
            "shift_ratio": round(shift_ratio, 3),
            "requires_review": requires_limit_review(shift_ratio)
        }
    return render_template("limit_review.html", result=result)

@app.route("/api/calculate-limits", methods=["POST"])
def api_calculate_limits():
    data = request.get_json() or {}
    required = ["yields", "bin_rates"]
    missing = [x for x in required if x not in data]
    if missing:
        return jsonify({"error": "Missing required fields", "missing": missing}), 400

    product_type = data.get("product_type", "standard")
    return jsonify(calculate_limits(data["yields"], data["bin_rates"], product_type))

@app.route("/api/evaluate-lot", methods=["POST"])
def api_evaluate_lot():
    data = request.get_json() or {}
    required = ["yield_percent", "bin_rate_percent", "bin_qty", "syl", "sbl", "sml"]
    missing = [x for x in required if x not in data]
    if missing:
        return jsonify({"error": "Missing required fields", "missing": missing}), 400

    result = evaluate_lot(
        yield_percent=float(data["yield_percent"]),
        bin_rate_percent=float(data["bin_rate_percent"]),
        bin_qty=int(data["bin_qty"]),
        syl=float(data["syl"]),
        sbl=float(data["sbl"]),
        sml=float(data["sml"]),
        small_quantity_rule=bool(data.get("small_quantity_rule", False)),
        asic_sbin=bool(data.get("asic_sbin", False))
    )
    return jsonify(result)
