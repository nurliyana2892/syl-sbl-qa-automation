# SYL/SBL Statistical Yield Limit QA Automation Project

Advanced QA Automation portfolio project for a QAPM / Manufacturing Quality professional moving into Software Testing and QA Automation.

This project is inspired by a Statistical Yield and Bin Limit procedure used in manufacturing test operations.

## Business Context

The application simulates a Manufacturing Execution System style workflow where:

- Production lot yield is evaluated against SYL
- Fail bin rate is evaluated against SBL
- Lot is automatically held when yield is below SYL
- Lot is automatically held when fail bin rate is above SBL
- Maverick hold is triggered when yield is below SML
- Small quantity QDN skip rule can auto release certain lots
- Limit review compares calculated limits against original limits
- QA/PE approval is required for limit changes

## Procedure Logic Implemented

### SYL / SBL / SML calculation

Standard product:
- SYL = mean yield - 3 sigma
- SBL = mean bin rate + 3 sigma
- SML = mean yield - 5 sigma

Automotive product:
- SYL = mean yield - 2 sigma

RP product:
- SYL = mean yield - 6 sigma
- SBL = mean bin rate + 6 sigma

### Hold decision

A lot is held when:
- Yield < SYL
- Any controlled fail bin rate > SBL
- Yield < SML

### Small quantity skip rule

A lot may be auto released when:
- Triggered bin quantity <= 8
- Bin yield loss < 5%

For ASIC FT SBin:
- Fail SBin quantity <= 2
- SBin yield loss <= 0.5%

## Tech Stack

- Python
- Flask demo web application
- Playwright
- Pytest
- Requests API testing
- Page Object Model
- HTML report
- GitHub Actions CI

## Setup

```bash
python -m venv .venv
source .venv/bin/activate
# Windows: .venv\Scripts\activate

pip install -r requirements.txt
playwright install
```

## Run app

```bash
python run_app.py
```

Open:

```text
http://127.0.0.1:5000
```

Login:

```text
username: qapm
password: quality123
```

## Run tests

Keep the app running, then open another terminal:

```bash
pytest
```

HTML report:

```bash
pytest --html=reports/report.html --self-contained-html
```

## Portfolio Value

This project shows:

- Software testing skill
- Python automation
- Playwright UI testing
- API testing
- Statistical rule validation
- Manufacturing quality domain knowledge
- Procedure-to-test traceability
- Risk-based test design
