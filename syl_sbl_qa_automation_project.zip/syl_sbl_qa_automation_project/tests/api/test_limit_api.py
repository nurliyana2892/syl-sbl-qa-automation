import requests

BASE_URL = "http://127.0.0.1:5000"

def test_api_calculate_limits_standard():
    payload = {
        "product_type": "standard",
        "yields": [96, 97, 98, 97, 96, 97, 98, 97, 96, 97,
                   98, 97, 96, 97, 98, 97, 96, 97, 98, 97,
                   96, 97, 98, 97, 96, 97, 98, 97, 96, 97],
        "bin_rates": [0.5, 0.6, 0.7, 0.6, 0.5, 0.6, 0.7, 0.6, 0.5, 0.6,
                      0.7, 0.6, 0.5, 0.6, 0.7, 0.6, 0.5, 0.6, 0.7, 0.6,
                      0.5, 0.6, 0.7, 0.6, 0.5, 0.6, 0.7, 0.6, 0.5, 0.6]
    }
    response = requests.post(f"{BASE_URL}/api/calculate-limits", json=payload)
    assert response.status_code == 200
    assert "syl" in response.json()
    assert "sbl" in response.json()

def test_api_evaluate_lot_high_bin_hold():
    payload = {
        "yield_percent": 96.0,
        "bin_rate_percent": 3.0,
        "bin_qty": 20,
        "syl": 95.0,
        "sbl": 2.0,
        "sml": 90.0
    }
    response = requests.post(f"{BASE_URL}/api/evaluate-lot", json=payload)
    assert response.status_code == 200
    assert response.json()["decision"] == "HOLD"
    assert "HIGH_FAIL_RATE_BIN_HOLD" in response.json()["reasons"]

def test_api_evaluate_lot_missing_required_field():
    response = requests.post(f"{BASE_URL}/api/evaluate-lot", json={"yield_percent": 96})
    assert response.status_code == 400
