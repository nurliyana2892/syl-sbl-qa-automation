def test_limit_review_requires_pe_qa_review(logged_in_page):
    logged_in_page.goto("http://127.0.0.1:5000/limit-review")
    logged_in_page.get_by_test_id("calculated-limit").fill("90")
    logged_in_page.get_by_test_id("original-limit").fill("95")
    logged_in_page.get_by_test_id("long-term-sigma").fill("2")
    logged_in_page.get_by_test_id("calculate-shift").click()
    assert logged_in_page.get_by_test_id("requires-review").inner_text() == "True"
