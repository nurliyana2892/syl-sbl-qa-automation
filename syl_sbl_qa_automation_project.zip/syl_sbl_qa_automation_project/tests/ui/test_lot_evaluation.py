from pages.lot_evaluation_page import LotEvaluationPage

def test_ui_lot_low_yield_hold(logged_in_page):
    lot = LotEvaluationPage(logged_in_page)
    lot.open()
    lot.evaluate("LOT-LOW-YIELD-001", 92.0, 0.8, 5)
    assert lot.decision() == "HOLD"

def test_ui_small_quantity_auto_release(logged_in_page):
    lot = LotEvaluationPage(logged_in_page)
    lot.open()
    lot.evaluate("LOT-SMALL-QTY-001", 96.0, 3.0, 8, small_rule=True)
    assert lot.decision() == "AUTO_RELEASE_QDN_SKIP"
