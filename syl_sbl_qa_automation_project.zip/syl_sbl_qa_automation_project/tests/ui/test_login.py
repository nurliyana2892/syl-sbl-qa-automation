from pages.login_page import LoginPage

def test_valid_login(page):
    login = LoginPage(page)
    login.open()
    login.login()
    assert page.get_by_test_id("dashboard-title").is_visible()

def test_invalid_login(page):
    login = LoginPage(page)
    login.open()
    login.login("bad", "bad")
    assert page.get_by_test_id("login-error").inner_text() == "Invalid username or password"
