import pytest
from pages.login_page import LoginPage

@pytest.fixture
def logged_in_page(page):
    login = LoginPage(page)
    login.open()
    login.login()
    page.get_by_test_id("dashboard-title").wait_for()
    return page
