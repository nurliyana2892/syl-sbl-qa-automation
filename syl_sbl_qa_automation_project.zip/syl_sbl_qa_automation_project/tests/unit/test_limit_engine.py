from core.limit_engine import calculate_limits, evaluate_lot, calculate_shift_ratio, requires_limit_review

def test_standard_syl_sbl_calculation():
    yields = [96, 97, 98, 97, 96, 97, 98, 97, 96, 97,
              98, 97, 96, 97, 98, 97, 96, 97, 98, 97,
              96, 97, 98, 97, 96, 97, 98, 97, 96, 97]
    bins = [0.5, 0.6, 0.7, 0.6, 0.5, 0.6, 0.7, 0.6, 0.5, 0.6,
            0.7, 0.6, 0.5, 0.6, 0.7, 0.6, 0.5, 0.6, 0.7, 0.6,
            0.5, 0.6, 0.7, 0.6, 0.5, 0.6, 0.7, 0.6, 0.5, 0.6]
    result = calculate_limits(yields, bins, "standard")
    assert "syl" in result
    assert "sbl" in result
    assert result["used_lots"] == 30

def test_low_yield_hold_triggered():
    result = evaluate_lot(92.0, 0.8, 5, syl=95.0, sbl=2.0, sml=90.0)
    assert result["decision"] == "HOLD"
    assert "LOW_YIELD_HOLD" in result["reasons"]

def test_high_fail_bin_hold_triggered():
    result = evaluate_lot(96.0, 3.0, 20, syl=95.0, sbl=2.0, sml=90.0)
    assert result["decision"] == "HOLD"
    assert "HIGH_FAIL_RATE_BIN_HOLD" in result["reasons"]

def test_maverick_yield_hold_triggered():
    result = evaluate_lot(89.0, 0.8, 5, syl=95.0, sbl=2.0, sml=90.0)
    assert "MAVERICK_YIELD_HOLD" in result["reasons"]

def test_small_quantity_qdn_skip_rule_auto_release():
    result = evaluate_lot(96.0, 3.0, 8, syl=95.0, sbl=2.0, sml=90.0, small_quantity_rule=True)
    assert result["decision"] == "AUTO_RELEASE_QDN_SKIP"

def test_asic_sbin_small_quantity_rule():
    result = evaluate_lot(96.0, 0.4, 2, syl=95.0, sbl=0.3, sml=90.0, small_quantity_rule=True, asic_sbin=True)
    assert result["decision"] == "AUTO_RELEASE_QDN_SKIP"

def test_shift_ratio_requires_review_when_more_than_2_sigma():
    ratio = calculate_shift_ratio(calculated_limit=90, original_limit=95, long_term_sigma=2)
    assert requires_limit_review(ratio) is True
